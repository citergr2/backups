<?php
header('Content-Type: application/json');

// --- SESUAIKAN KONFIGURASI DATABASE ANDA DI SINI ---
$host = "localhost";
$user = "root";       // Username database Anda (default XAMPP: root)
$pass = "";           // Password database Anda (default XAMPP: kosong)
$db   = "db_sekolah"; // Nama database MariaDB Anda
// ---------------------------------------------------

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Koneksi database gagal"]);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];

// Jika ada yang mengirim pesan (POST)
if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $name = trim($data['name'] ?? '');
    $msg  = trim($data['msg'] ?? '');

    if (!empty($name) && !empty($msg)) {
        $stmt = $conn->prepare("INSERT INTO ucapan (name, msg) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $msg);
        if ($stmt->execute()) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error"]);
        }
        $stmt->close();
    }
} 
// Jika ingin mengambil daftar pesan (GET)
else if ($method === 'GET') {
    $result = $conn->query("SELECT name, msg, created_at FROM ucapan ORDER BY id DESC");
    $ucapan = [];
    while($row = $result->fetch_assoc()) {
        $ucapan[] = $row;
    }
    echo json_encode($ucapan);
}

$conn->close();
?>
